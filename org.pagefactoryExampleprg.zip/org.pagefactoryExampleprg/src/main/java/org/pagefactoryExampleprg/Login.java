package org.pagefactoryExampleprg;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;
public class Login {
@Test
    public void LoginforLuma() throws InterruptedException {
        // Set the path of the Chrome driver
    	System.setProperty("webdriver.chrome.driver","D:\\chromedriver-win64\\chromedriver.exe");
    	ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
        driver.get("https://magento.softwaretestingboard.com/customer/account/login/referer/aHR0cHM6Ly9tYWdlbnRvLnNvZnR3YXJldGVzdGluZ2JvYXJkLmNvbS9jdXN0b21lci9hY2NvdW50L2NyZWF0ZS8%2C/");
        Thread.sleep(4000);
        driver.manage().window().maximize();
        LumaLoginPage loginPage = new LumaLoginPage(driver);
        loginPage.enterEmail("tesqualitythought@gmail.com");
        loginPage.clickNextButton();
        loginPage.enterPassword("test@1234");
        loginPage.clickNextButton();

    }
}

