package org.cucumberextendsreport;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;
 
public class BaseClass {
	
	
	   
	    private static BaseClass helperClass;
	     
	    private static WebDriver driver;
	    private static WebDriverWait wait;
	    public final static int TIMEOUT = 10;
	     
	     private BaseClass() {
	          
	    		System.setProperty("webdriver.chrome.driver","D:\\chromedriver-win64\\chromedriver.exe");
	    		ChromeOptions options = new ChromeOptions();
	    		options.addArguments("--remote-allow-origins=*");
	    		DesiredCapabilities capabilities = new DesiredCapabilities();
	    		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	    		options.merge(capabilities);
	    		ChromeDriver driver = new ChromeDriver(options);
	            driver.manage().window().maximize();
	     }      
	             
	    public static void openPage(String url) {
	        driver.get(url);
	    }
	 
	     
	    public static WebDriver getDriver() {
	        return driver;              
	    }
	     
	    public static void setUpDriver() {
	         
	        if (helperClass==null) {
	             
	            helperClass = new BaseClass();
	        }
	    }
	     
	     public static void tearDown() {
	          
	         if(driver!=null) {
	             driver.close();
	             driver.quit();
	         }
	          
	         helperClass = null;
	     } 
	     
	}


