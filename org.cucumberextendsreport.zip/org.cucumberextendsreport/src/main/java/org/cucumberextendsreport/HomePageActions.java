package org.cucumberextendsreport;

public class HomePageActions {

}
