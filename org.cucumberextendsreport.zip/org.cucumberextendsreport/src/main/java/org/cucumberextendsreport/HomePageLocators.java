package org.cucumberextendsreport;

public class HomePageLocators {

	public String getHomePageText() {
		// TODO Auto-generated method stub
		return null;
	}

}
