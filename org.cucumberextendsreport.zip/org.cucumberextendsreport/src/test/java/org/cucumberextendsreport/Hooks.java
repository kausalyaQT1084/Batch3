package org.cucumberextendsreport;

import org.cucumberextendsreport.*;
import io.cucumber.java.After;
import io.cucumber.java.Before;
 
public class Hooks {
     
    @Before
    public static void setUp() {
 
       BaseClass.setUpDriver();
    }
     
    @After
    public static void tearDown() {
         
    	BaseClass.tearDown();
    }
}