package org.cucumberextendsreport;

import org.testng.Assert;
import org.cucumberextendsreport.HomePageLocators;
import org.cucumberextendsreport.LoginPageLocators;
import org.cucumberextendsreport.BaseClass;
import org.cucumberextendsreport.HomePageActions;
import org.cucumberextendsreport.LoginPageActions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Step;
 
public class LoginPageDefinitions{  
 
    LoginPageActions objLogin = new LoginPageActions();
    HomePageActions objHomePage = new HomePageActions();
         
  @Step
    @Given("User is on HRMLogin page {string}")
    public void loginTest(String url) {
         
        BaseClass.openPage(url);
  
    }
  @Step
    @When("User enters username as {string} and password as {string}")
    public void goToHomePage(String userName, String passWord) {
  
        // login to application
        objLogin.login(userName, passWord);
  
        // go the next page
         
    }
 
    @Then("User should be able to login sucessfully and new page open")
    public void verifyLogin() {
    	HomePageLocators objHomePage= new HomePageLocators();
  
        // Verify home page
        Assert.assertTrue(objHomePage.getHomePageText().contains("Welcome"));
  
    }
    
    @Then("User should be able to see error message {string}")
    public void verifyErrorMessage(String expectedErrorMessage) {
  
        // Verify home page
        Assert.assertEquals(objLogin.getErrorMessage(),expectedErrorMessage);
  
    }
     @Step
    @Then("User should be able to see LinkedIn Icon")
    public void verifyLinkedInIcon( ) {
         
        Assert.assertTrue(objLogin.getLinkedInIcon());
    }
     @Step
    @Then("User should be able to see FaceBook Icon")
    public void verifyFaceBookIcon( ) {
         
        Assert.assertTrue(objLogin.getFaceBookIcon());
    }
       
}
